package com.example.riyadh;


import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("/99c279bb173a6e28359c/data")
    Call<ArrayList<ModelSurah>> getListSurah();

    @GET("/99c279bb173a6e28359c/surat/{nomor}")
    Call<ArrayList<ModelAyat>> getDetailSurah(@Path("nomor") String nomor);

    @GET("place/nearbysearch/json")
    Call<ModelResultNearby> getDataResult(
            @Query("key") String key,
            @Query("keyword") String keyword,
            @Query("location") String location,
            @Query("rankby") String rankby
    );
}
