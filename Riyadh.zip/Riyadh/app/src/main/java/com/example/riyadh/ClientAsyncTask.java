//package com.example.riyadh;
//
//
//import android.os.AsyncTask;
//
//import java.io.BufferedReader;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.net.HttpURLConnection;
//import java.net.URL;
//
//public class ClientAsyncTask extends AsyncTask<String, String, String> {
//    private static final int CONNECTON_TIMEOUT_MILLISECONDS = 60000;
//    private final FragmentJadwalSholat mContext;
//    private final OnPostExecuteListener mPostExecuteListener;
//
//    public ClientAsyncTask(FragmentJadwalSholat context, OnPostExecuteListener postExecuteListener) {
//        this.mContext = context;
//        this.mPostExecuteListener = postExecuteListener;
//    }
//
//    public interface OnPostExecuteListener {
//        void onPostExecute(String result);
//    }
//
//    @Override
//    protected void onPostExecute(String result) {
//        super.onPostExecute(result);
//        mPostExecuteListener.onPostExecute(result);
//    }
//
//    @Override
//    protected String doInBackground(String... urls) {
//        HttpURLConnection urlConnection = null;
//
//        try {
//            URL url = new URL(urls[0]);
//
//            urlConnection = (HttpURLConnection) url.openConnection();
//            urlConnection.setConnectTimeout(CONNECTON_TIMEOUT_MILLISECONDS);
//            urlConnection.setReadTimeout(CONNECTON_TIMEOUT_MILLISECONDS);
//
//            String inString = streamToString(urlConnection.getInputStream());
//
//            return inString;
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        } finally {
//            if (urlConnection != null) {
//                urlConnection.disconnect();
//            }
//        }
//
//        return "";
//    }
//
//    private String streamToString(InputStream inputStream) {
//        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
//        StringBuilder stringBuilder = new StringBuilder();
//        String line;
//
//        try {
//            while ((line = bufferedReader.readLine()) != null) {
//                stringBuilder.append(line);
//            }
//            inputStream.close();
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//
//        return stringBuilder.toString();
//    }
//}
