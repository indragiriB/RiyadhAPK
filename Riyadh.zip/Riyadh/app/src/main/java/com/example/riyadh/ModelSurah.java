package com.example.riyadh;



import com.google.gson.annotations.SerializedName;
import java.io.Serializable;

public class ModelSurah implements Serializable {
    @SerializedName("arti")
    private String arti;

    @SerializedName("asma")
    private String asma;

    @SerializedName("ayat")
    private String ayat;

    @SerializedName("nama")
    private String nama;

    @SerializedName("type")
    private String type;

    @SerializedName("audio")
    private String audio;

    @SerializedName("nomor")
    private String nomor;

    @SerializedName("keterangan")
    private String keterangan;

    public String getArti() {
        return arti;
    }

    public void setArti(String arti) {
        this.arti = arti;
    }

    public String getAsma() {
        return asma;
    }

    public void setAsma(String asma) {
        this.asma = asma;
    }

    public String getAyat() {
        return ayat;
    }

    public void setAyat(String ayat) {
        this.ayat = ayat;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAudio() {
        return audio;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }

    public String getNomor() {
        return nomor;
    }

    public void setNomor(String nomor) {
        this.nomor = nomor;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }
}
