package com.example.riyadh;

import androidx.lifecycle.ViewModel;

public class AlquranViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}