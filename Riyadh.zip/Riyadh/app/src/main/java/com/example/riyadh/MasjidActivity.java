package com.example.riyadh;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProvider.NewInstanceFactory;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

import im.delight.android.location.SimpleLocation;

public class MasjidActivity extends AppCompatActivity implements OnMapReadyCallback {

    private double strCurrentLatitude = 0.0;
    private double strCurrentLongitude = 0.0;
    private String strCurrentLocation;
    private GoogleMap mapsView;
    private SimpleLocation simpleLocation;
    private ProgressDialog progressDialog;
    private MasjidViewModel masjidViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_masjid);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Mohon Tunggu…");
        progressDialog.setCancelable(false);
        progressDialog.setMessage("sedang menampilkan lokasi");

        setInitLayout();
    }

    private void setInitLayout() {
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(null);
        setSupportActionBar(toolbar);
        assert getSupportActionBar() != null;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        simpleLocation = new SimpleLocation(this);
        if (!simpleLocation.hasLocationEnabled()) {
            SimpleLocation.openSettings(this);
        }

        //get location
        strCurrentLatitude = simpleLocation.getLatitude();
        strCurrentLongitude = simpleLocation.getLongitude();

        //set location lat long
        strCurrentLocation = strCurrentLatitude + "," + strCurrentLongitude;

        SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapFragment);
        supportMapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mapsView = googleMap;

        //viewmodel
        setViewModel();
    }

    private void setViewModel() {
        progressDialog.show();
        masjidViewModel = new ViewModelProvider(this, new NewInstanceFactory()).get(MasjidViewModel.class);
        masjidViewModel.setMarkerLocation(strCurrentLocation);
        masjidViewModel.getMarkerLocation().observe(this, modelResults -> {
            if (modelResults.size() != 0) {

                //get multiple marker
                getMarker(modelResults);
                progressDialog.dismiss();
            } else {
                Toast.makeText(this, "Oops, tidak bisa mendapatkan lokasi kamu!", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
            progressDialog.dismiss();
        });
    }

    private void getMarker(ArrayList<ModelResults> modelResultsArrayList) {
        for (int i = 0; i < modelResultsArrayList.size(); i++) {

            //set LatLong from API
            LatLng latLngMarker = new LatLng(
                    modelResultsArrayList.get(i)
                            .getModelGeometry()
                            .getModelLocation()
                            .getLat(), modelResultsArrayList.get(i)
                    .getModelGeometry()
                    .getModelLocation()
                    .getLng()
            );

            //get LatLong to Marker
            mapsView.addMarker(
                    new MarkerOptions()
                            .position(latLngMarker)
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                            .title(modelResultsArrayList.get(i).getName())
            );

            //show Marker
            LatLng latLngResult = new LatLng(
                    modelResultsArrayList.get(0).getModelGeometry()
                            .getModelLocation()
                            .getLat(), modelResultsArrayList.get(0)
                    .getModelGeometry()
                    .getModelLocation()
                    .getLng()
            );

            //set position marker
            mapsView.moveCamera(CameraUpdateFactory.newLatLng(latLngResult));
            mapsView.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(
                            new LatLng(
                                    latLngResult.latitude,
                                    latLngResult.longitude
                            ), 14f
                    )
            );
            mapsView.getUiSettings().setAllGesturesEnabled(true);
            mapsView.getUiSettings().setZoomGesturesEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
