package com.example.riyadh;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class AlquranFragment extends Fragment {

    private static final String ARG_SURAH_NUMBER = "surahNumber";

    private int surahNumber;
    private String surahContent;
    private ArrayList<String> audioUrls = new ArrayList<>();
    private MediaPlayer mediaPlayer;
    private int audioIndex = 0; // Indeks audio yang sedang diputar

    public AlquranFragment() {
        // Required empty public constructor
    }

    public static AlquranFragment newInstance(int surahNumber) {
        AlquranFragment fragment = new AlquranFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SURAH_NUMBER, surahNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            surahNumber = getArguments().getInt(ARG_SURAH_NUMBER);
        }

        // Mengambil konten surah dari file JSON
        try {
            InputStream is = getResources().openRawResource(R.raw.audio);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String json = new String(buffer, StandardCharsets.UTF_8);

            JSONObject jsonObject = new JSONObject(json);
            JSONArray surahsArray = jsonObject.getJSONObject("data").getJSONArray("surahs");

            JSONObject surahObject = surahsArray.getJSONObject(surahNumber - 1); // -1 karena indeks dimulai dari 0
            StringBuilder contentBuilder = new StringBuilder();
            contentBuilder.append(surahObject.getString("name")).append(" (")
                    .append(surahObject.getString("englishName")).append(")\n\n");

            JSONArray ayahsArray = surahObject.getJSONArray("ayahs");
            for (int i = 0; i < ayahsArray.length(); i++) {
                JSONObject ayahObject = ayahsArray.getJSONObject(i);
                contentBuilder.append(ayahObject.getString("text")).append("\n\n");

                // Menambahkan URL audio ke dalam ArrayList
                String audioUrl = ayahObject.getString("audio");
                audioUrls.add(audioUrl);
            }

            surahContent = contentBuilder.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_alquran, container, false);
        TextView textView = view.findViewById(R.id.textViewSurahContent);
        textView.setText(surahContent);

        SeekBar seekBarTextSize = view.findViewById(R.id.seekBarTextSize);
        seekBarTextSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textView.setTextSize(progress * 0.5f); // Menyesuaikan ukuran teks berdasarkan nilai seekbar
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Tidak diperlukan
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Tidak diperlukan
            }
        });

        Button playButton = view.findViewById(R.id.buttonPlayAudio);
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playAudio();
            }
        });

        return view;
    }

    private void playAudio() {
        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(audioUrls.get(audioIndex));
                mediaPlayer.prepare();

                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        // Pemutaran audio berikutnya setelah audio saat ini selesai
                        audioIndex++;
                        if (audioIndex < audioUrls.size()) {
                            try {
                                mediaPlayer.reset();
                                mediaPlayer.setDataSource(audioUrls.get(audioIndex));
                                mediaPlayer.prepare();
                                mediaPlayer.start();
                            } catch (Exception e) {
                                e.printStackTrace();
                                Toast.makeText(getContext(), "Error playing audio", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Jika sudah memutar semua audio, reset audioIndex ke 0
                            audioIndex = 0;
                        }
                    }
                });

                mediaPlayer.start(); // Pemutaran dimulai setelah menetapkan listener

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getContext(), "Error playing audio", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Media player sudah ada, hentikan dan buat ulang untuk memainkan audio berikutnya
            mediaPlayer.release();
            mediaPlayer = null;
            playAudio(); // Memainkan audio berikutnya
        }
    }
}