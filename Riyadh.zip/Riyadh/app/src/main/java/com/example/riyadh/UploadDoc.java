package com.example.riyadh;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class UploadDoc extends AppCompatActivity {

    ImageView upload;
    EditText pdfNameEditText; // tambahkan EditText untuk nama PDF
    Uri imageuri = null;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_doc);
        upload = findViewById(R.id.uploadpdf);
        pdfNameEditText = findViewById(R.id.pdfNameEditText); // inisialisasi EditText

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("application/pdf");
                startActivityForResult(galleryIntent, 1);
            }
        });


        // Set bottom navigation listener
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.bottom_home);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.bottom_home) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (itemId == R.id.bottom_search) {
                startActivity(new Intent(getApplicationContext(), TambahPengumumanActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (itemId == R.id.bottom_settings) {

                return true;
            } else if (itemId == R.id.bottom_profile) {
                startActivity(new Intent(getApplicationContext(), UploadActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            }
            return false;
        });


        // Tambahkan FAB untuk mengirim data ke Firebase
        FloatingActionButton fabSendToFirebase = findViewById(R.id.fabSendToFirebase);
        fabSendToFirebase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imageuri != null) {
                    uploadToFirebase(imageuri); // Panggil metode uploadToFirebase() saat FAB diklik
                } else {
                    Toast.makeText(UploadDoc.this, "Please select a PDF", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Temukan ImageView yang ingin diberi onClickListener
        ImageView pdfImageView = findViewById(R.id.tiga);
        ImageView listImageView = findViewById(R.id.empat);
        ImageView imgImageView = findViewById(R.id.lima);
        ImageView profileImageView = findViewById(R.id.enam);

        // Set onClickListener untuk ImageView
        pdfImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman PDF
                Intent intent = new Intent(UploadDoc.this, PdfListActivity.class);
                startActivity(intent);
            }
        });

        listImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman List
                Intent intent = new Intent(UploadDoc.this, LihatPengumumanActivity.class);
                startActivity(intent);
            }
        });

        imgImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman Image
                Intent intent = new Intent(UploadDoc.this, LihatGambarActivity.class);
                startActivity(intent);
            }
        });

        profileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman Profile
                Intent intent = new Intent(UploadDoc.this, Dashboard.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageuri = data.getData();
            dialog = new ProgressDialog(this);
            dialog.setMessage("Uploading");
            dialog.show();

            final String pdfName = pdfNameEditText.getText().toString().trim(); // Ambil nama PDF dari EditText
            if (pdfName.isEmpty()) {
                Toast.makeText(this, "Please enter PDF name", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                return;
            }

            final String timestamp = String.valueOf(System.currentTimeMillis());
            final String messagePushID = timestamp + "_" + pdfName; // Gabungkan timestamp dan nama PDF

            StorageReference storageReference = FirebaseStorage.getInstance().getReference();
            final StorageReference filepath = storageReference.child(messagePushID + ".pdf");

            UploadTask uploadTask = filepath.putFile(imageuri);
            uploadTask.continueWithTask(task -> {
                if (!task.isSuccessful()) {
                    throw task.getException();
                }
                return filepath.getDownloadUrl();
            }).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    dialog.dismiss();
                    Uri uri = task.getResult();
                    String pdfUrl = uri.toString();

                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("PDFs");
                    Map<String, Object> pdfInfo = new HashMap<>();
                    pdfInfo.put("pdfUrl", pdfUrl);
                    pdfInfo.put("timestamp", timestamp);
                    pdfInfo.put("pdfName", pdfName); // Simpan nama PDF ke Firebase

                    databaseReference.child(messagePushID).setValue(pdfInfo)
                            .addOnCompleteListener(task1 -> {
                                if (task1.isSuccessful()) {
                                    Toast.makeText(UploadDoc.this, "PDF Uploaded and Info Saved", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(UploadDoc.this, "Failed to Save PDF Info", Toast.LENGTH_SHORT).show();
                                }
                            });

                    Intent intent = new Intent(UploadDoc.this, PdfListActivity.class);
                    intent.putExtra("pdfUrl", pdfUrl);
                    startActivity(intent);
                } else {
                    dialog.dismiss();
                    Toast.makeText(UploadDoc.this, "Upload Failed", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    // Metode untuk meng-upload file ke Firebase
    private void uploadToFirebase(Uri uri) {
        String pdfName = pdfNameEditText.getText().toString().trim(); // Dapatkan nama PDF dari EditText
        if (pdfName.isEmpty()) {
            Toast.makeText(this, "Please enter PDF name", Toast.LENGTH_SHORT).show();
            return;
        }

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Uploading PDF...");
        progressDialog.show();

        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        final StorageReference filePath = storageReference.child("PDFs").child(pdfName + ".pdf");

        UploadTask uploadTask = filePath.putFile(uri);
        uploadTask.addOnSuccessListener(taskSnapshot -> {
            // Upload sukses, dapatkan URL download
            filePath.getDownloadUrl().addOnSuccessListener(uriResult -> {
                String downloadUrl = uriResult.toString();

                // Simpan informasi PDF ke Firebase Database
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("PDFs");
                String uploadId = databaseReference.push().getKey();

                Map<String, Object> pdfInfo = new HashMap<>();
                pdfInfo.put("pdfName", pdfName);
                pdfInfo.put("pdfUrl", downloadUrl);
                pdfInfo.put("timestamp", System.currentTimeMillis());

                if (uploadId != null) {
                    databaseReference.child(uploadId).setValue(pdfInfo)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    progressDialog.dismiss();
                                    Toast.makeText(UploadDoc.this, "PDF Uploaded and Info Saved", Toast.LENGTH_SHORT).show();
                                } else {
                                    progressDialog.dismiss();
                                    Toast.makeText(UploadDoc.this, "Failed to Save PDF Info", Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    progressDialog.dismiss();
                    Toast.makeText(UploadDoc.this, "Upload ID is null", Toast.LENGTH_SHORT).show();
                }
            });
        }).addOnFailureListener(e -> {
            progressDialog.dismiss();
            Toast.makeText(UploadDoc.this, "Upload Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }).addOnProgressListener(snapshot -> {
            // Menampilkan progress upload
            double progress = (100.0 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();
            progressDialog.setMessage("Uploading PDF: " + (int) progress + "%");
        });
    }

}
