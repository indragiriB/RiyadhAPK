package com.example.riyadh;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Calendar;

import im.delight.android.location.SimpleLocation;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_PERMISSION = 100;

    private double strCurrentLatitude = 0.0;
    private double strCurrentLongitude = 0.0;
    public String strCurrentLatLong;
    private String strDate;
    private String strDateNow;
    private SimpleLocation simpleLocation;
    private MainAdapter mainAdapter;
    private ProgressDialog progressDialog;
    private SurahViewModel surahViewModel;
    private MySharedPreferences mySharedPreferences;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mySharedPreferences = new MySharedPreferences(this);
        setInitLayout();
//        setPermission();
//        displayUserName();
    }

    private void setInitLayout() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Mohon Tunggu");
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Sedang menampilkan data...");

        Calendar calendar = Calendar.getInstance();
        strDate = DateFormat.format("EEEE", calendar).toString();
        strDateNow = DateFormat.format("d MMMM yyyy", calendar).toString();

        // Initialize views
        mainAdapter = new MainAdapter(this);
        androidx.recyclerview.widget.RecyclerView rvSurah = findViewById(R.id.rvSurah);
        rvSurah.setHasFixedSize(true);
        rvSurah.setLayoutManager(new LinearLayoutManager(this));
        rvSurah.setAdapter(mainAdapter);

        // Set click listeners
        TextView tvToday = findViewById(R.id.tvToday);
        TextView tvDate = findViewById(R.id.tvDate);
        tvToday.setText(strDate);
        tvDate.setText(strDateNow);

        // Initialize image views
        ImageView pdfImageView = findViewById(R.id.tiga);
        ImageView listImageView = findViewById(R.id.empat);
        ImageView imgImageView = findViewById(R.id.lima);
        ImageView profileImageView = findViewById(R.id.enam);

        // Set onClickListeners for image views
        pdfImageView.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PdfListActivity.class);
            startActivity(intent);
        });

        listImageView.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LihatPengumumanActivity.class);
            startActivity(intent);
        });

        imgImageView.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LihatGambarActivity.class);
            startActivity(intent);
        });

        profileImageView.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Dashboard.class);
            startActivity(intent);
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.bottom_home);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.bottom_home) {
                return true;
            } else if (itemId == R.id.bottom_search) {
                startActivity(new Intent(getApplicationContext(), TambahPengumumanActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (itemId == R.id.bottom_settings) {
                startActivity(new Intent(getApplicationContext(), UploadDoc.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (itemId == R.id.bottom_profile) {
                startActivity(new Intent(getApplicationContext(), UploadActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            }
            return false;
        });

        setViewModel();
    }

//    private void displayUserName() {
//        String username = mySharedPreferences.getUsername();
//        TextView tvUsername = findViewById(R.id.tvUsername); // Make sure you have a TextView with this id in your layout
//        tvUsername.setText(username);
//    }

//    private void setPermission() {
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
//                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_PERMISSION);
//        } else {
//            setLocation();
//            setCurrentLocation();
//        }
//    }

//    private void setLocation() {
//        simpleLocation = new SimpleLocation(this);
//        if (!simpleLocation.hasLocationEnabled()) {
//            SimpleLocation.openSettings(this);
//        }
//
//        // Get location
//        strCurrentLatitude = simpleLocation.getLatitude();
//        strCurrentLongitude = simpleLocation.getLongitude();
//
//        // Set location lat long
//        strCurrentLatLong = strCurrentLatitude + "," + strCurrentLongitude;
//    }
//
//    private void setCurrentLocation() {
//        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
//        try {
//            android.location.Address address = geocoder.getFromLocation(strCurrentLatitude, strCurrentLongitude, 1).get(0);
//            if (address != null) {
//                String strCurrentLocation = address.getLocality();
//                TextView tvLocation = findViewById(R.id.tvLocation);
//                tvLocation.setText(strCurrentLocation);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    private void setViewModel() {
        progressDialog.show();
        surahViewModel = new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(SurahViewModel.class);
        surahViewModel.setSurah();
        surahViewModel.getSurah().observe(this, modelSurah -> {
            if (modelSurah.size() != 0) {
                mainAdapter.setAdapter(modelSurah);
                progressDialog.dismiss();
            } else {
                Toast.makeText(this, "Data Tidak Ditemukan!", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });
    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == REQ_PERMISSION) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                setLocation();
//                setCurrentLocation();
//            } else {
//                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
//                // Handle the case where permission is not granted
//                TextView tvLocation = findViewById(R.id.tvLocation);
//                tvLocation.setText("Location not available");
//            }
//        }
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PERMISSION && resultCode == RESULT_OK) {
            // Reload data
            setViewModel();
        }
    }
}
