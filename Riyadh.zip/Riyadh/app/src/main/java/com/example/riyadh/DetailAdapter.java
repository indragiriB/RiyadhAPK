package com.example.riyadh;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DetailAdapter extends RecyclerView.Adapter<DetailAdapter.ViewHolder> {
    private final ArrayList<ModelAyat> modelAyatList = new ArrayList<>();

    public void setAdapter(ArrayList<ModelAyat> items) {
        modelAyatList.clear();
        modelAyatList.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_ayat, parent, false);
        return new ViewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ModelAyat data = modelAyatList.get(position);

        holder.tvNomorAyat.setText(data.getNomor());
        holder.tvArabic.setText(data.getArab());
        holder.tvTerjemahan.setText(data.getIndo());
    }

    @Override
    public int getItemCount() {
        return modelAyatList.size();
    }

    // ViewHolder class
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNomorAyat;
        TextView tvArabic;
        TextView tvTerjemahan;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNomorAyat = itemView.findViewById(R.id.tvNomorAyat);
            tvArabic = itemView.findViewById(R.id.tvArabic);
            tvTerjemahan = itemView.findViewById(R.id.tvTerjemahan);
        }
    }
}
