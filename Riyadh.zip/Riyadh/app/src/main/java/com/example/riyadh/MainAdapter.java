package com.example.riyadh;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {
    private final Context mContext;
    private final ArrayList<ModelSurah> modelSurahList = new ArrayList<>();

    public MainAdapter(Context context) {
        this.mContext = context;
    }

    public void setAdapter(ArrayList<ModelSurah> items) {
        modelSurahList.clear();
        modelSurahList.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_surah, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ModelSurah data = modelSurahList.get(position);

        holder.tvNumber.setText(data.getNomor());
        holder.tvName.setText(data.getAsma());
        holder.tvAyat.setText(data.getNama());
        holder.tvInfo.setText(data.getType() + " - " + data.getAyat() + " Ayat ");

        holder.cvSurah.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, DetailActivity.class);
            intent.putExtra(DetailActivity.DETAIL_SURAH, modelSurahList.get(position));
            mContext.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return modelSurahList.size();
    }

    // ViewHolder class
    public static class ViewHolder extends RecyclerView.ViewHolder {
        CardView cvSurah;
        TextView tvNumber;
        TextView tvAyat;
        TextView tvInfo;
        TextView tvName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cvSurah = itemView.findViewById(R.id.cvSurah);
            tvNumber = itemView.findViewById(R.id.tvNumber);
            tvAyat = itemView.findViewById(R.id.tvAyat);
            tvInfo = itemView.findViewById(R.id.tvInfo);
            tvName = itemView.findViewById(R.id.tvName);
        }
    }
}
