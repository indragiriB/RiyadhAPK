package com.example.riyadh;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.messaging.FirebaseMessaging;

public class Dashboard extends AppCompatActivity {

    String emailHolder;
    TextView email;
    Button logOut, buttonTambahPengumuman, buttonLihatPengumuman, buttonLihatAlquran, buttonLihatAudio;
    FirebaseAuth mAuth;
    SharedPreferences sharedPref;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);  // Set the content view first

        FirebaseMessaging.getInstance().subscribeToTopic("pengumuman");
        FirebaseMessaging.getInstance().setAutoInitEnabled(true);

        Toolbar toolbar = findViewById(R.id.toolbar);  // Now find the toolbar
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish(); // This will close the current activity and go back to the previous one
            }
        });

        logOut = findViewById(R.id.button1);

        mAuth = FirebaseAuth.getInstance();

        sharedPref = getSharedPreferences("loginPrefs", MODE_PRIVATE);

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                // Clear login status from SharedPreferences
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean("isLoggedIn", false);
                editor.apply();
                Toast.makeText(Dashboard.this, "Log Out Successful", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Dashboard.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
