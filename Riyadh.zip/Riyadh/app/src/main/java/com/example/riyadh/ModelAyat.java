package com.example.riyadh;


import com.google.gson.annotations.SerializedName;

public class ModelAyat {
    @SerializedName("ar")
    private String arab;

    @SerializedName("id")
    private String indo;

    @SerializedName("nomor")
    private String nomor;

    public String getArab() {
        return arab;
    }

    public void setArab(String arab) {
        this.arab = arab;
    }

    public String getIndo() {
        return indo;
    }

    public void setIndo(String indo) {
        this.indo = indo;
    }

    public String getNomor() {
        return nomor;
    }

    public void setNomor(String nomor) {
        this.nomor = nomor;
    }
}
