package com.example.riyadh;


import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SurahViewModel extends ViewModel {
    private MutableLiveData<ArrayList<ModelSurah>> modelSurahMutableLiveData = new MutableLiveData<>();
    private MutableLiveData<ArrayList<ModelAyat>> modelAyatMutableLiveData = new MutableLiveData<>();

    public void setSurah() {
        ApiInterface apiService = ApiService.getQuran();
        Call<ArrayList<ModelSurah>> call = apiService.getListSurah();

        call.enqueue(new Callback<ArrayList<ModelSurah>>() {
            @Override
            public void onResponse(Call<ArrayList<ModelSurah>> call, Response<ArrayList<ModelSurah>> response) {
                if (!response.isSuccessful()) {
                    Log.e("response", String.valueOf(response));
                } else if (response.body() != null) {
                    ArrayList<ModelSurah> items = new ArrayList<>(response.body());
                    modelSurahMutableLiveData.postValue(items);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<ModelSurah>> call, Throwable t) {
                Log.e("failure", t.toString());
            }
        });
    }

    public void setDetailSurah(String nomor) {
        ApiInterface apiService = ApiService.getQuran();
        Call<ArrayList<ModelAyat>> call = apiService.getDetailSurah(nomor);

        call.enqueue(new Callback<ArrayList<ModelAyat>>() {
            @Override
            public void onResponse(Call<ArrayList<ModelAyat>> call, Response<ArrayList<ModelAyat>> response) {
                if (!response.isSuccessful()) {
                    Log.e("response", String.valueOf(response));
                } else if (response.body() != null) {
                    ArrayList<ModelAyat> items = new ArrayList<>(response.body());
                    modelAyatMutableLiveData.postValue(items);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<ModelAyat>> call, Throwable t) {
                Log.e("failure", t.toString());
            }
        });
    }

    public LiveData<ArrayList<ModelSurah>> getSurah() {
        return modelSurahMutableLiveData;
    }

    public LiveData<ArrayList<ModelAyat>> getDetailSurah() {
        return modelAyatMutableLiveData;
    }
}
