package com.example.riyadh;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class TambahPengumumanActivity extends AppCompatActivity {

    private EditText editTextTitle, editTextContent;
    private Button buttonAddAnnouncement;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    private void addAnnouncement() {
        String title = editTextTitle.getText().toString().trim();
        String content = editTextContent.getText().toString().trim();

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(content)) {
            Toast.makeText(this, "Title and content are required", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference newAnnouncementRef = mDatabase.push();
        newAnnouncementRef.child("title").setValue(title);
        newAnnouncementRef.child("content").setValue(content);

        // Notify all users
        notifyAllUsers(title, content);

        Toast.makeText(this, "Announcement added successfully", Toast.LENGTH_SHORT).show();
        finish(); // Close the activity after adding announcement
    }

    private void notifyAllUsers(String title, String content) {
        mDatabase.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<String> tokens = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String token = snapshot.child("fcmToken").getValue(String.class);
                    if (token != null) {
                        tokens.add(token);
                    }
                }
                sendNotification(tokens, title, content);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors.
            }
        });
    }

    private void sendNotification(List<String> tokens, String title, String content) {
        OkHttpClient client = new OkHttpClient();
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        for (String token : tokens) {
            JSONObject json = new JSONObject();
            try {
                JSONObject notification = new JSONObject();
                notification.put("title", title);
                notification.put("body", content);

                json.put("to", token);
                json.put("notification", notification);

                RequestBody body = RequestBody.create(json.toString(), JSON);
                Request request = new Request.Builder()
                        .url("https://fcm.googleapis.com/fcm/send")
                        .post(body)
                        .addHeader("Authorization", "key=AAAAqH8zTcM:APA91bGF2KOneq5593j-6XvfbI_S7-cxB--KAZhSTuQ5DUgU9CEytLtz0pedTRg9dIu1fAjbeT2uGWSPCRBNykf5WaYfiZMJXSzRDlEjtsXCezh4gxfTcC3I5Rlo66MH07FKQzQhzDZM") // Replace with your server key
                        .build();

                client.newCall(request).enqueue(new okhttp3.Callback() {
                    @Override
                    public void onFailure(@NonNull okhttp3.Call call, @NonNull IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(@NonNull okhttp3.Call call, @NonNull Response response) throws IOException {
                        if (!response.isSuccessful()) {
                            throw new IOException("Unexpected code " + response);
                        }
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }



    void callAPi(JSONObject jsonObject){
 MediaType JSON = MediaType.get("application/json");

        OkHttpClient client = new OkHttpClient();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_pengumuman);

        FirebaseMessaging.getInstance().subscribeToTopic("pengumuman");
        FirebaseMessaging.getInstance().setAutoInitEnabled(true);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference().child("announcements");

        editTextTitle = findViewById(R.id.editTextTitle);
        editTextContent = findViewById(R.id.editTextContent);
        buttonAddAnnouncement = findViewById(R.id.buttonAddAnnouncement);

        buttonAddAnnouncement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addAnnouncement();
            }
        });


        // Temukan ImageView yang ingin diberi onClickListener
        ImageView pdfImageView = findViewById(R.id.tiga);
        ImageView listImageView = findViewById(R.id.empat);
        ImageView imgImageView = findViewById(R.id.lima);
        ImageView profileImageView = findViewById(R.id.enam);

        // Set onClickListener untuk ImageView
        pdfImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman PDF
                Intent intent = new Intent( TambahPengumumanActivity.this, PdfListActivity.class);
                startActivity(intent);
            }
        });

        listImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman List
                Intent intent = new Intent( TambahPengumumanActivity.this, LihatPengumumanActivity.class);
                startActivity(intent);
            }
        });

        imgImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman Image
                Intent intent = new Intent( TambahPengumumanActivity.this, LihatGambarActivity.class);
                startActivity(intent);
            }
        });

        profileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman Profile
                Intent intent = new Intent( TambahPengumumanActivity.this, Dashboard.class);
                startActivity(intent);
            }
        });





        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
        bottomNavigationView.setSelectedItemId(R.id.bottom_home);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.bottom_home) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (itemId == R.id.bottom_search) {

                return true;
            } else if (itemId == R.id.bottom_settings) {
                startActivity(new Intent(getApplicationContext(), UploadDoc.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            } else if (itemId == R.id.bottom_profile) {
                startActivity(new Intent(getApplicationContext(), UploadActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
                return true;
            }
            return false;
        });

    }


}

