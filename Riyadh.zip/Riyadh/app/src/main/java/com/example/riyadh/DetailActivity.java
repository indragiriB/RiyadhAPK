package com.example.riyadh;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.util.Objects;

public class DetailActivity extends AppCompatActivity {
    private String strNomor;
    private String strNama;
    private String strArti;
    private String strType;
    private String strAyat;
    private String strKeterangan;
    private String strAudio;
    private ModelSurah modelSurah;
    private DetailAdapter detailAdapter;
    private ProgressDialog progressDialog;
    private SurahViewModel surahViewModel;
    private Handler handler;
    private FloatingActionButton fabPlay;
    private FloatingActionButton fabStop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        fabPlay = findViewById(R.id.fabPlay);
        fabStop = findViewById(R.id.fabStop);
        setInitLayout();
        setViewModel();
    }

    @SuppressLint("RestrictedApi")
    private void setInitLayout() {
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(null);
        setSupportActionBar(toolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        handler = new Handler();

        modelSurah = (ModelSurah) Objects.requireNonNull(getIntent().getSerializableExtra(DETAIL_SURAH));
        if (modelSurah != null) {
            strNomor = modelSurah.getNomor();
            strNama = modelSurah.getNama();
            strArti = modelSurah.getArti();

            strType = modelSurah.getType();
            strAyat = modelSurah.getAyat();
            strAudio = modelSurah.getAudio();
            strKeterangan = modelSurah.getKeterangan();

            fabStop.setVisibility(View.GONE);
            fabPlay.setVisibility(View.VISIBLE);


            //Set text
            TextView tvHeader = findViewById(R.id.tvHeader);
            TextView tvTitle = findViewById(R.id.tvTitle);

            TextView tvSubTitle = findViewById(R.id.tvSubTitle);
            TextView tvInfo = findViewById(R.id.tvInfo);
            TextView tvKet = findViewById(R.id.tvKet);
            tvHeader.setText(strNama);
            tvTitle.setText(strNama);
            tvSubTitle.setText(strArti);


            tvInfo.setText(strType + " - " + strAyat + " Ayat ");











            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                tvKet.setText(Html.fromHtml(strKeterangan, Html.FROM_HTML_MODE_COMPACT));
            } else {
                tvKet.setText(Html.fromHtml(strKeterangan));
            }


            MediaPlayer mediaPlayer = new MediaPlayer();
            fabPlay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        mediaPlayer.setDataSource(strAudio);
                        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                            @Override
                            public void onPrepared(MediaPlayer mp) {
                                // Set audio stream type after MediaPlayer is prepared
                                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                                mediaPlayer.start();
                            }
                        });
                        mediaPlayer.prepareAsync();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    fabPlay.setVisibility(View.GONE);
                    fabStop.setVisibility(View.VISIBLE);
                }
            });


            fabStop.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop();
                    }
                    mediaPlayer.reset(); // Reset the MediaPlayer to its uninitialized state
                    fabPlay.setVisibility(View.VISIBLE);
                    fabStop.setVisibility(View.GONE);
                }
            });





        }

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Mohon Tunggu");
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Sedang menampilkan data...");

        detailAdapter = new DetailAdapter();
        androidx.recyclerview.widget.RecyclerView rvAyat = findViewById(R.id.rvAyat);
        rvAyat.setHasFixedSize(true);
        rvAyat.setLayoutManager(new LinearLayoutManager(this));
        rvAyat.setAdapter(detailAdapter);
    }

    private void setViewModel() {
        progressDialog.show();
        surahViewModel = new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(SurahViewModel.class);
        surahViewModel.setDetailSurah(strNomor);
        surahViewModel.getDetailSurah().observe(this, modelAyat -> {
            if (modelAyat.size() != 0) {
                detailAdapter.setAdapter(modelAyat);
                progressDialog.dismiss();
            } else {
                Toast.makeText(this, "Data Tidak Ditemukan!", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
            progressDialog.dismiss();
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);


    }






    public static final String DETAIL_SURAH = "DETAIL_SURAH";
}
