package com.example.riyadh;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class LihatPengumumanActivity extends AppCompatActivity {

    private ListView listViewAnnouncements;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private List<String> announcementList;
    private String currentUserEmail;
    private String strDate;
    private String strDateNow;

    private ArrayAdapter<String> adapter;
    private MainAdapter mainAdapter;
    private DetailAdapter detailAdapter;
    private ProgressDialog progressDialog;
    private BottomNavigationView bottomNavigationView;
    private boolean isHidden = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lihat_pengumuman);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LihatPengumumanActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish(); // This will close the current activity and go back to the previous one
            }
        });


        // Inisialisasi ListView dan adapter
        listViewAnnouncements = findViewById(R.id.listViewAnnouncements);
        announcementList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, announcementList);
        listViewAnnouncements.setAdapter(adapter);

        // Temukan ImageView yang ingin diberi onClickListener
        ImageView pdfImageView = findViewById(R.id.tiga);
        ImageView listImageView = findViewById(R.id.empat);
        ImageView imgImageView = findViewById(R.id.lima);
        ImageView profileImageView = findViewById(R.id.enam);

        // Set onClickListener untuk ImageView
        pdfImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman PDF
                Intent intent = new Intent( LihatPengumumanActivity.this, PdfListActivity.class);
                startActivity(intent);
            }
        });



        imgImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman Image
                Intent intent = new Intent( LihatPengumumanActivity.this, LihatGambarActivity.class);
                startActivity(intent);
            }
        });

        profileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman Profile
                Intent intent = new Intent( LihatPengumumanActivity.this, Dashboard.class);
                startActivity(intent);
            }
        });





        // Dummy data untuk ListView
        for (int i = 0; i < 20; i++) {
            announcementList.add("Item " + i);
        }
        adapter.notifyDataSetChanged();

        // Atur tinggi ListView secara dinamis berdasarkan jumlah item
        setListViewHeightBasedOnItems(listViewAnnouncements);


        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference().child("announcements");
        announcementList = new ArrayList<>();

//        // Inisialisasi elemen TextView untuk menampilkan email pengguna
//        TextView textViewCurrentUserEmail = findViewById(R.id.textViewCurrentUserEmail);
//        if (currentUser != null) {
//            String userEmail = currentUser.getDisplayName();
//            textViewCurrentUserEmail.setText("Email: " + userEmail);
//        }

        // Inisialisasi dan atur adapter untuk ListView seperti sebelumnya
        listViewAnnouncements = findViewById(R.id.listViewAnnouncements);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, announcementList);
        listViewAnnouncements.setAdapter(adapter);

        // Tambahkan listener untuk pengumuman dari Firebase Database seperti sebelumnya
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                announcementList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String title = snapshot.child("title").getValue(String.class);
                    String content = snapshot.child("content").getValue(String.class);
                    announcementList.add(title + "\n" + content);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error
            }
        });

//
//        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);
//        bottomNavigationView.setSelectedItemId(R.id.bottom_home);
//        bottomNavigationView.setOnItemSelectedListener(item -> {
//            int itemId = item.getItemId();
//            if (itemId == R.id.bottom_home) {
//                startActivity(new Intent(getApplicationContext(), MainActivity.class));
//                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
//                finish();
//                return true;
//            } else if (itemId == R.id.bottom_search) {
//                startActivity(new Intent(getApplicationContext(), TambahPengumumanActivity.class));
//                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
//                finish();
//                return true;
//            } else if (itemId == R.id.bottom_settings) {
//                return true;
//            } else if (itemId == R.id.bottom_profile) {
//                startActivity(new Intent(getApplicationContext(),LihatGambarActivity.class));
//                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
//                finish();
//                return true;
//            }
//            return false;
//        });
    }

    private void setListViewHeightBasedOnItems(ListView listView) {
        if (adapter == null) {
            return;
        }
        int totalHeight = 0;
        int itemHeight = 0;
        int itemCount = adapter.getCount();

        for (int i = 0; i < itemCount; i++) {
            View listItem = adapter.getView(i, null, listView);
            listItem.measure(0, 0);
            itemHeight = listItem.getMeasuredHeight();
            totalHeight += itemHeight;
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (itemCount - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }




}

