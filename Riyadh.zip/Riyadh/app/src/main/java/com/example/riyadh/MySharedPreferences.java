package com.example.riyadh;

import android.content.Context;
import android.content.SharedPreferences;

public class MySharedPreferences {

    private static final String PREF_NAME = "MyAppPreferences";
    private static final String KEY_ALQURAN_TEXT = "AlquranText";
    private static final String KEY_USERNAME = "Username";

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public MySharedPreferences(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void saveAlquranText(String alquranText) {
        editor.putString(KEY_ALQURAN_TEXT, alquranText);
        editor.apply();
    }

    public String getAlquranText() {
        return sharedPreferences.getString(KEY_ALQURAN_TEXT, "");
    }

    public void saveUsername(String username) {
        editor.putString(KEY_USERNAME, username);
        editor.apply();
    }

    public String getUsername() {
        return sharedPreferences.getString(KEY_USERNAME,"");
    }
}
