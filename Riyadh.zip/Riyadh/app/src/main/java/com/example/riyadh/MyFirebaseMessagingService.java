package com.example.riyadh;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        // Simpan token FCM ke Firebase Realtime Database atau Firestore
        saveTokenToDatabase(token);
    }

    private void saveTokenToDatabase(String token) {
        // Dapatkan ID pengguna saat ini (misalnya, dari FirebaseAuth)
        String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Simpan token FCM ke Firebase Realtime Database pada lokasi yang sesuai (misalnya, di bawah node "users/{userId}/token")
        DatabaseReference userTokenRef = FirebaseDatabase.getInstance().getReference()
                .child("users")
                .child(currentUserId)
                .child("token");

        userTokenRef.setValue(token)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("MyFirebaseMessaging", "Token FCM berhasil disimpan ke database.");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.e("MyFirebaseMessaging", "Gagal menyimpan token FCM ke database: " + e.getMessage());
                    }
                });
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        // Handle penerimaan pesan notifikasi di sini jika diperlukan
    }
}