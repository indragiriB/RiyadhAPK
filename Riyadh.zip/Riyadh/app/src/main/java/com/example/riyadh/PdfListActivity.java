package com.example.riyadh;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class PdfListActivity extends AppCompatActivity {

    private ListView pdfListView;
    private List<String> pdfNamesList;
    private List<String> pdfUrlsList;
    private ArrayAdapter<String> pdfListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_list);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PdfListActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish(); // This will close the current activity and go back to the previous one
            }
        });

        // Temukan ImageView yang ingin diberi onClickListener
        ImageView pdfImageView = findViewById(R.id.tiga);
        ImageView imgImageView = findViewById(R.id.lima);
        ImageView profileImageView = findViewById(R.id.enam);

        // Set onClickListener untuk ImageView
        pdfImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman PDF
                Intent intent = new Intent( PdfListActivity.this, LihatPengumumanActivity.class);
                startActivity(intent);
            }
        });


        imgImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman Image
                Intent intent = new Intent( PdfListActivity.this, LihatGambarActivity.class);
                startActivity(intent);
            }
        });

        profileImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Panggil Intent untuk menuju ke halaman Profile
                Intent intent = new Intent( PdfListActivity.this, Dashboard.class);
                startActivity(intent);
            }
        });


        pdfListView = findViewById(R.id.pdfListView);
        pdfNamesList = new ArrayList<>();
        pdfUrlsList = new ArrayList<>();
        pdfListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, pdfNamesList);
        pdfListView.setAdapter(pdfListAdapter);

        DatabaseReference pdfsRef = FirebaseDatabase.getInstance().getReference().child("PDFs");
        pdfsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                pdfNamesList.clear();
                pdfUrlsList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    // Pastikan nilai dari snapshot.child("pdfName") dan snapshot.child("pdfUrl") tidak null sebelum mengambil nilainya
                    if (snapshot.child("pdfName").getValue() != null && snapshot.child("pdfUrl").getValue() != null) {
                        String pdfName = snapshot.child("pdfName").getValue(String.class);
                        String pdfUrl = snapshot.child("pdfUrl").getValue(String.class);
                        pdfNamesList.add(pdfName);
                        pdfUrlsList.add(pdfUrl);
                    }
                }
                pdfListAdapter.notifyDataSetChanged();

                // Set tinggi ListView agar bisa di-scroll di dalam NestedScrollView
                setListViewHeightBasedOnItems(pdfListView);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle onCancelled
            }
        });

        pdfListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String pdfUrl = pdfUrlsList.get(position);
                openPdf(pdfUrl);
            }
        });
    }

    private void setListViewHeightBasedOnItems(ListView listView) {
        if (listView == null) {
            return;
        }
        ArrayAdapter adapter = (ArrayAdapter) listView.getAdapter();
        if (adapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0; i < adapter.getCount(); i++) {
            View listItem = adapter.getView(i, null, listView);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (adapter.getCount() - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }

    private void openPdf(String pdfUrl) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.parse(pdfUrl), "application/pdf");
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Error opening PDF", Toast.LENGTH_SHORT).show();
        }
    }
}
